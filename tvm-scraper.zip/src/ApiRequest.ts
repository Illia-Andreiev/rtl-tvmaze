import {get, IncomingMessage} from 'http';

export class ApiResponseError extends Error {
  constructor(public statusCode: number) {
    super();
    this.message = `Request Failed. Status Code: ${statusCode}`;
  }
}

export class ApiRequestError extends Error {
  constructor(public originalError: any) {
    super();
  }
}

export class ApiRequest {
  static get<T>(path: string): Promise<T> {
    return new Promise((resolve, reject) => {
      get(path, (response: IncomingMessage) => {
        const {statusCode} = response;

        if (statusCode !== 200) {
          reject(new ApiResponseError(statusCode));
          response.resume();
          return;
        }

        response.setEncoding('utf8');
        let loadedData = '';
        response.on('data', function (chunk) {
          loadedData += chunk;
        });

        response.on('end', function () {
          resolve(JSON.parse(loadedData));
        });

      }).on('error', (e) => {
        reject(new ApiRequestError(e));
      });
    });
  }
}