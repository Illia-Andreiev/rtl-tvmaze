export const SERVER_PORT = 3000;
export const ATTEMPTS_NUMBER = 10;
export const SHOW_PER_PAGE = 5;
export const API_URL = 'http://api.tvmaze.com';
export const STORAGE_FILE = 'dist/storage/cast.json';