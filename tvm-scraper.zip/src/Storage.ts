import * as fs from 'fs';
import {FetchedShow} from './TVmazeAPI';
import {SHOW_PER_PAGE, STORAGE_FILE} from './Constant';

interface StorageInterface {
  saveCast(data: FetchedShow[]): void,

  getPage(page: number): Promise<string>,

  getShows(): Promise<string>
}

export class Storage implements StorageInterface {

  public saveCast(data: FetchedShow[]): void {
    fs.writeFile(STORAGE_FILE, JSON.stringify(data), 'utf8', (err => {
      if (err) throw err;
    }));
  }

  public getPage(page: number): Promise<string> {
    return this.getShows().then((cast) => {
      return JSON.stringify(JSON.parse(cast).slice(page * SHOW_PER_PAGE - SHOW_PER_PAGE, page * SHOW_PER_PAGE));
    });
  }

  public getShows(): Promise<string> {
    return new Promise((resolve, reject) => {
      fs.readFile(STORAGE_FILE, 'utf8', function (err, data) {
        if (err) reject(err);
        resolve(data);
      });
    });
  }
}