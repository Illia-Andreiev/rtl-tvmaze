import {TVmazeAPI} from './TVmazeAPI';
import {Storage} from './Storage';
import * as http from 'http';
import {IncomingMessage, ServerResponse} from 'http';
import {API_URL, SERVER_PORT} from './Constant';


async function main() {
  const tvmazeApi = new TVmazeAPI(API_URL);
  const fetchedCast = await tvmazeApi.fetchShows();
  const storage = new Storage();
  storage.saveCast(fetchedCast);

  http.createServer()
    .on('request', async (req: IncomingMessage, res: ServerResponse) => {
        const {url} = req;
        const paramRegexp = /\/(\d+)/;

        if (url === '/') {
          const cast = await storage.getShows();
          res.setHeader('Content-Type', 'application/json');
          res.end(cast);

        } else if (paramRegexp.test(url)) {
          const matches = url.match(paramRegexp);
          const pagedCast = await storage.getPage(+matches[1]);
          res.setHeader('Content-Type', 'application/json');
          res.end(pagedCast);

        } else {
          res.statusCode = 404;
          res.end();
        }
      }
    )
    .listen(SERVER_PORT);
  console.log(`Server listening on port: ${SERVER_PORT}`);
}

main();



